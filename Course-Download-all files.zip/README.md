Building-a-website
==================

The course code samples for the Putting it together: Building a website course found at Learnable.com

If you want to get your hands dirty and build a website with HTML and CSS, this course is for you. You will learn how to use the main tools that these languages give to build a complete and complex homepage of a website. This is a practical course covering the main techniques web developers use for building a variety of common page elements.

This course is taught by Guilherme Muller and was tech reviewed by Joni Trythall.


Course Repository Structure
===========================

The master branch is made up of the final website files used in the course. To download the course files relevant to each course lesson, please download the resources from the repository tags.

Each lesson's start and final lesson files are grouped and tagged.
